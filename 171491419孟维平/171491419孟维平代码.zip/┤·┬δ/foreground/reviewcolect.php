<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>评论收集</title>
</head>
<body>
<?php
include("Conn.php");
$sql="INSERT INTO review (rcontent) VALUES 
('$_POST[rcontent]')";
mysqli_query($db,$sql);


?>
</body>
</html>

