<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>邓伦主页</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#FFFFFF"topmargin="0" leftmargin="0">

<?php

include("Conn.php");
include("func.php");//ad(#1,#2,#3)������
include("top.php");
include("top2.php");
include("body.php");

?>



</body>
</html>

