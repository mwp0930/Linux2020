<style type="text/css">
<!--
.STYLE2 {
	font-size: 56px;
	font-family: "宋体";
}
.STYLE3 {font-family: "宋体"}
-->
</style><table width="778" border="0" cellspacing="0" cellpadding="2" align="center" height="400" background="images/1.png">
  <tr >
<?php
include("Conn.php");
$sql = "Select * From dlnews where bigclassname='basic'";
$myquery=mysqli_query($db,$sql);
$row = mysqli_fetch_array($myquery); 


?>
    <td><table height="330"width="350" border="0" cellspacing="0" cellpadding="2">
      <tr>
        <td valign="top" style="color:#6699FF" height="76"><p class="STYLE2">邓伦</p>          </td>
      </tr>
      <tr>
        <td height="105" align="center" valign="top"><div align="justify" class="STYLE3"><?php echo $row["content"]; ?><a href="information.html" target="_blank">更多..</a></div>
      </tr>
	  <tr>
    <td align="left"><a href="images/1.jfif" target="_blank"><img src="images/1.jfif" /></a>   <a href="images/timg-1.jpeg" target="_blank"><img src="images/timg-1.jpeg" /></a>   <a href="images/3.jpg" target="_blank"><img src="images/3.jpg" /></a></td>
  </tr>
    </table></td>
  </tr>
</table>

