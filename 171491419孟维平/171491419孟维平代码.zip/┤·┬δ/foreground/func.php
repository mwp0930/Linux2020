<?php function ad($c,$n,$a) {?>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr  bgcolor="#CCCCFF">
    <td width="38%" height="36"><img src="images/indict1.gif" align="absmiddle"><?php echo $c ?></td>
    <td width="44%">&nbsp;</td>
    <td width="18%"><a href="class_list.php?cn=<?php echo $c; ?>" target="_blank">更多</a></td>
  </tr>
<?php
include("Conn.php");
$sqlf = "Select * From dlnews where bigclassname='$c'limit $n ";
$myqueryf=mysqli_query($db,$sqlf);
$row1 = mysqli_num_rows($myqueryf);
for($i=0;$i<$row1;$i++)
{
$rowf = mysqli_fetch_assoc($myqueryf);
?>  
  <tr>
    <td><a href="news_disp.php?xwh=<?php echo $rowf["ID"]; ?>" target="_blank"><?php echo $rowf["title"]; ?></a></td>
	<td colspan="2"><?php echo mb_substr($rowf["content"],0,21); ?></td>
  </tr>
<?php

}

?>  
</table>
<embed src="images/<?php echo $a ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" width="578" height="150">
</object>
<?php } ?>

