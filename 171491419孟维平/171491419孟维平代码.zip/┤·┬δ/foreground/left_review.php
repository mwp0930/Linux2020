<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>评论</title>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#CCFFFF">
    <td colspan="2" align="center" style="color:#99CC00"><img src="images/indict1.gif" align="absmiddle">评论区</td>
	</tr>
</table>
<marquee bgcolor="#CCFFFF" direction="up" height="142" scrollamount="4" scrolldelay="1"  onmouseout="this.start();"onmouseover="this.stop();">
<table align="center" width="100%" border="0" cellspacing="0" cellpadding="2">
  <?php
include("Conn.php");
$sql = "Select * From review  ";
$myquery=mysqli_query($db,$sql);
if (!$myquery) echo "SQL������".mysqli_error();
$row1 = mysqli_num_rows($myquery);
for($i=0;$i<$row1;$i++)
{
$row = mysqli_fetch_assoc($myquery);
?>
  <tr>
    <td width="325" bgcolor="#CCFFFF"><?php echo $i+1; ?>楼</td>
  </tr>
  <tr>
    <td colspan="3" bgcolor="#CCFFFF"><?php echo $row["rcontent"]; ?></td>
  </tr>
  <?php

}
?>
</table>
</marquee>
<form action="reviewcolect.php" method="post" name="rev" onSubmit="return myReview();">
<table bgcolor="#CCFFFF"  align="center" width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td  bgcolor="#CCFFFF"align="center"><img src="images/indict1.gif" align="absmiddle">发表评论<input name="rcontent" type="text" size="12"></td>
  </tr>
  <tr>
    <td align="center"><input name="tj" type="submit" value="提交" style="color:#CC66FF"></td>
  </tr>
  <tr>
    <td align="center"><img src="images/indict1.gif" align="absmiddle" />网友印象</td>
  </tr>
</table>
<img style="color:#CCFFFF" width="100%" src="images/yinxiang.JPG" align="absmiddle">
</form>
</body>
</html>
<script language="javascript">
function myReview()
{
	content=document.rev.rcontent.value;
	if(content.length==0)
	{
		alert("请输入您的评论内容");
		return false;
	}
	else
	{
		alert("您的评论已提交");
	}
}
		
</script>
