<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>相关信息浏览</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php 
include("Conn.php");
include("top.php");
$xwid = $_GET["wk"];
$sql = "Select * From works where workid=$xwid";
$myquery=mysqli_query($db,$sql);
$row = mysqli_fetch_array($myquery);
?>
<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#CCFFFF">
    <th style="font-size:36px"><?php echo $row["workname"]; ?></th>
  </tr>
  <tr bgcolor="#CCFFCC">
    <td>
	catalogue<?php echo $row["workclass"]; ?><br>
	content<?php echo $row["workcontent"]; ?><br>
	</td>
	</tr>
</table>

</body>
</html>

