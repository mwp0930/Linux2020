<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="200" background="images/001.JPG" valign="top">
	<?php
	include("left_timer.php");
	include("left_seek.php");
	include("left_daibiaozuo.php");
        include("left_recommend.php");
        include("left_review.php");
	?>
	</td>
    <td width="578" bgcolor="#FFFFFF" valign="top">
<?php
$sql = "Select * From bigclass where homepage";
$myquery=mysqli_query($db,$sql);
$row1 = mysqli_num_rows($myquery);
for($i=0;$i<$row1;$i++)
{
$row = mysqli_fetch_assoc($myquery);
$ccc=$row["bigclassname"]; 
$nnn=$row["rmax"]; 
$aaa=$row["ad"]; 
ad($ccc,$nnn,$aaa);

}

?>

	</td>
  </tr>
</table>

