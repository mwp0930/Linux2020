<table width="778" border="0" cellspacing="0" cellpadding="2" align="center" height="33" background="images/001.JPG">
  <tr>
<?php
$sql = "Select bigclassname From bigclass ";
$myquery=mysqli_query($db,$sql);
$row1 = mysqli_num_rows($myquery);
for($i=0;$i<$row1;$i++)
{
$row = mysqli_fetch_assoc($myquery);
?>
    <td style="color:#9966FF" align="center" onMouseOver="this.bgColor='#999999'" onMouseOut="this.bgColor=''">
	 <img src="images/news.gif" align="absmiddle">
	 <a href="class_list.php?cn=<?php echo $row["bigclassname"]; ?>" target="_blank">
	  <?php echo $row["bigclassname"]; ?>
	 </a>
	 
	</td>
<?php

}

?>
  </tr>
</table>

