d>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>推荐信息</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php 
include("Conn.php");
include("top.php");
$xwid = $_GET["re"];
$sql = "Select * From rec where ID=$xwid";
$myquery=mysqli_query($db,$sql);
$row = mysqli_fetch_array($myquery);
?>
<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#CCFFFF">
    <th style="font-size:36px"><?php echo $row["rectitle"]; ?></th>
  </tr>
  <tr bgcolor="#CCFFCC">
    <td>
	<?php echo $row["reccontent"]; ?><br>
	<br>
	<embed src="images/<?php echo $row["recphoto"] ?>" ><br>
	</td>
	</tr>
</table>

</body>
</html>

