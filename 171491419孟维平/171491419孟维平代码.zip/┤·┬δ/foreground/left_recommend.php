<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#CCFFFF">
    <td colspan="2" align="center" style="color:#99CC00"><img src="images/indict1.gif" align="absmiddle">相关推荐</td>
	</tr>
</table>
<marquee bgcolor="#CCFFFF" direction="up" height="110" scrollamount="4" scrolldelay="1"  onmouseout="this.start();"onmouseover="this.stop();">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<?php
include("conn.php");
$sql = "Select * From rec";
$myquery=mysqli_query($db,$sql);
$row1 = mysqli_num_rows($myquery);
for($i=0;$i<$row1;$i++)
{
$row = mysqli_fetch_assoc($myquery);
?>  
  <tr>
    <td height="22" align="left"><a href="recs_disp.php?re=<?php echo $row["ID"]; ?>" target="_blank">#<?php echo $row["rectitle"] ?>#</a></td>  
  </tr>
<?php

}

?>
    

  
</table>
</marquee>

