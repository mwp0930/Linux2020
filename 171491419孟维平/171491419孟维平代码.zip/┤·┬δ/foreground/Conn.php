<?php
$db=mysqli_connect('localhost','root','0930','dln');
	if (!$db)
	{
		die('Could not connect: ' . mysqli_error($con));
	}
	
	mysqli_select_db($db,"dln");
 
	mysqli_set_charset($db, "utf8");
?>


