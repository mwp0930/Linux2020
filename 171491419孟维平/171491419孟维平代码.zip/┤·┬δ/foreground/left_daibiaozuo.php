<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#CCFFFF">
    <td colspan="2" align="center" style="color:#CC33FF"><img src="images/indict1.gif" align="absmiddle">代表作品</td>
	</tr>
</table>
<marquee bgcolor="#CCFFFF" direction="up" height="160" scrollamount="4" scrolldelay="1"  onmouseout="this.start();"onmouseover="this.stop();">
<table  width="100%" border="0" cellspacing="0" cellpadding="2">
<?php
include("Conn.php");
$sql = "Select * From works";
$myquery=mysqli_query($db,$sql);
$row1 = mysqli_num_rows($myquery);
for($i=0;$i<$row1;$i++)
{
$row = mysqli_fetch_assoc($myquery);
?>  
  <tr>
    <td height="40" align="left"><a href="works_disp.php?wk=<?php echo $row["workid"]; ?>" target="_blank">
    <embed src="images/<?php echo $row["workphoto"] ?>" ></a></td>
	<td align="center" style="font-size:16px" ><?php echo $row["workname"]; ?></td>
    
  </tr>
<?php

}

?>
    

  
</table>
</marquee>

