<table height="100" width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#CCFFFF">
    <td height="28" align="center" style="color:#CC33FF"><img src="images/search.gif" align="absmiddle" />搜一搜</td>
  </tr>
  <tr>
    <td height="80" bgcolor="#CCFFFF" align="center"><form action="seek_list.php" method="post" name="formseek" target="_blank">
      <input name="kkk" type="text" size="12" />
      <br />
      <input name="ppp" type="radio" value="nr" checked />
      内容
      <input name="ppp" type="radio" value="bt" />
      标题<br />
      <input name="submit" type="submit" style="color:#6600CC"value="查询" />
    </form></td>
  </tr>
</table>

