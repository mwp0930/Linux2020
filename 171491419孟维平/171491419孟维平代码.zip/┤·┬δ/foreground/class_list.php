<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>相关信息分类</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php 
include("Conn.php");
include("top.php");

$ccc=$_GET["cn"];

?>
<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#FF9900">
    <th colspan="5"><?php echo $ccc ?></th>
  </tr>
  <tr bgcolor="#FFCC00">
    <td width="57" align="center">ID</td>
    <td width="170" align="center">类别</td>
    <td width="415" align="center">具体信息</td>
    <td width="142" align="center">发布时间</td>
  </tr>
<?php
$sql = "Select * From dlnews where bigclassname='$ccc'";
$myquery=mysqli_query($db,$sql);
$row1 = mysqli_num_rows($myquery);
for($i=0;$i<$row1;$i++)
{
$row = mysqli_fetch_assoc($myquery);
?> 
  
  <tr bgcolor="#FFFFFF" height="20">
    <td align="center"><?php echo $row["ID"]; ?></td>
    <td align="center"><a href="news_disp.php?xwh=<?php echo $row["ID"]; ?>" target="_blank" title="<?php echo $row["title"]; ?>"><?php echo $row["title"]; ?></a></td>
    <td align="center"><?php echo mb_substr($row["content"],0,20); ?></td>
    <td align="center"><?php echo date("Y-m-d",strtotime($row["time"]));?></td>
  </tr>
<?php
 
}

?>
</table>


</body>
</html>

