<?php 
include("Conn.php");//$db
$xwh = $_GET["xwh"];
$pg = $_GET["page"];


$sql="delete from dlnews where ID=$xwh";
$result=mysqli_query($db,$sql);


if($result)
    echo "<script>{alert('删除成功');document.location.href='information_page.php?page=$pg'} </script>";
else 
    echo "<script>{alert('删除失败');history.back();'} </scrip>";


?>

