<?php 
include("Conn.php");
$bbtt = $_POST["bt"];
$lblb = $_POST["lb"];
$sjsj = $_POST["sj"];
$nrnr = $_POST["nr"];
$sql="insert into dlnews (title,bigclassname,time,content) values('$bbtt','$lblb','$sjsj','$nrnr')";

$result=mysqli_query($db,$sql);


if($result)
    echo "<script>{alert('添加成功');location.href='information_page.php'} </script>";
else 
    echo "<script>{alert('添加失败');history.back();} </script>";


?>
