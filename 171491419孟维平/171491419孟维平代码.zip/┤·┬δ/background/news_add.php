<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>添加信息</title>
</head>

<body>
<?php 
include("select_date.php");
include("Conn.php");
$sql = "Select bigclassname From bigclass";
?>
<form action="news_add_save.php" method="post" name="formadd" onSubmit="return CheckForm();">
<h1 align="center">请添加信息</h1>
<table width="600" border="1" cellspacing="0" cellpadding="2" align="center">
  <tr>
    <td width="86" bgcolor="#FF9900">标题</td>
    <td width="500"><input name="bt" type="text" size="60" maxlength="60"></td>
  </tr>
  <tr>
    <td bgcolor="#FF9900">类别</td>
    <td><select name="lb" size="1">
<?php $myqueryf=mysqli_query($db,$sql);
while($row = mysqli_fetch_array($myqueryf))
{
  ?>
      <option value="<?php echo $row["bigclassname"]; ?>"><?php echo $row["bigclassname"]; ?></option>
<?php
}
?>     
	</select>
	</td>
  </tr>
  <tr>
    <td bgcolor="#FF9900">时间</td>
    <td>
	<input name="sj" type="text" value="<?php echo date('Y-m-d')?>" size="60" maxlength="60" readonly="true" id="select_date" onFocus="javascript:ShowCalendar(this.id)">
	</td>
  </tr>
  <tr>
    <td bgcolor="#FF9900">内容</td>
    <td><textarea name="nr" cols="60" rows="7"></textarea></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="tj" type="submit" value="提交新闻">&nbsp;
	<input name="tj" type="button" value="取消">
	</td>
  </tr>
</table>
</form>

</body>
</html>
<script language="javascript">
function CheckForm()
{
if(document.formadd.bt.value.trim()=="")
{
        alert("输入标题");
		document.formadd.bt.focus();
		return false;
}
if(document.formadd.nr.value.trim()=="")
{
        alert("输入内容");
		document.formadd.nr.focus();
		return false;
}

return true;
}

</script>

