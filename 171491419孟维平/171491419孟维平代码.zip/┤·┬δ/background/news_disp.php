<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>相关信息浏览</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<?php 
include("Conn.php");
$xwid = $_GET["xwh"];
$sql = "Select * From dlnews where id=$xwid";
$myquery=mysqli_query($db,$sql);
$row = mysqli_fetch_array($myquery);
?>
<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#CCFFFF">
    <th style="font-size:36px"><?php echo $row["title"]; ?></th>
  </tr>
  <tr bgcolor="#CCFFCC">
    <td>
	信息类别：<?php echo $row["bigclassname"]; ?><br>
	标题：<?php echo $row["title"]; ?><br>
	时间：<?php echo date("Y-m-d",strtotime($row["time"]));?><br>
	</td>
  </tr>
  <tr bgcolor="#99CCFF">
    <td><?php echo $row["content"]; ?></td>
  </tr>
</table>

</body>
</html>

