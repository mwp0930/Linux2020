<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>信息列表</title>
</head>

<body bgcolor="#99CCFF">
<h1 align="center" >信息列表</h1>
<center><a href="news_add.php" target="_blank">添加信息</a></center>
<table width="900" border="1" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#FF9966">
    <td width="51">ID</td>
    <td width="504">title</td>
    <td width="128">time</td>
    <td width="102">op</td>
  </tr>
<?php
include("Conn.php");//$db
$myquery = mysqli_query($db,"select count(*) from dlnews");
$row = mysqli_fetch_array($myquery);
$num_cnt = $row[0];	
$page_size = 10;
$page_cnt = ceil($num_cnt / $page_size); 

if(isset($_GET['p'])){ $page = $_GET['p']; } else { $page = 1; }

$query_start = ($page - 1) * $page_size; 
$querysql = "select * from dlnews limit $query_start, $page_size"; 
$queryset = mysqli_query($db,$querysql); 
while($row = mysqli_fetch_array($queryset))
	{ 
?>

  <tr bgcolor="#9999FF">
    <td><?php echo $row["ID"]; ?></td>
    <td><a href="news_disp.php?xwh= <?php echo $row["ID"]; ?>" target="_blank"><?php echo mb_substr($row["title"],0,20,"gb2312"); ?></a></td>
    <td><?php echo date("Y-m-d",strtotime($row["time"])); ?></td>
	<td>
	<a href="news_modi.php?xwh=<?php echo $row["ID"]; ?>&page=<?php echo $page ?>">修改</a>
	&nbsp;&nbsp;
	<a href="news_del.php?xwh=<?php echo $row["ID"]; ?>&page=<?php echo $page ?>">删除</a>
	</td>
  </tr>
  

<?php

}
?>

</table><br>
<center>共<?php echo $num_cnt?>条记录；每页<?php echo $page_size?>条记录；共<?php echo $page_cnt?>页 <br>跳转至第
<?php
if($page_cnt > 1)
	{ 
	?>
	<?php for($i=1; $i <= $page_cnt; $i++)
	{?>	
		 <?php if($page==$i){?> <?php echo $i  ?>
		 <?php } 
		 else{ ?> <a href="?p=<?php echo $i ?>"> <?php echo $i ?> </a>&nbsp; 
		 <?php } }?>页</center>

<?php
}	 
mysqli_close($db);
?>
</body>
</html>

