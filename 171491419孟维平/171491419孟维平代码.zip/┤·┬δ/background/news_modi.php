<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>修改信息</title>
</head>

<body>
<?php 
include("select_date.php");
include("Conn.php");
$xwh = $_GET["xwh"];
$pg = $_GET["page"];
$sqlmodi = "select * from dlnews where ID=$xwh";
$myquery=mysqli_query($db,$sqlmodi);
$row = mysqli_fetch_array($myquery);
$btbt=$row["title"];
$lblb=$row["bigclassname"];
$sjsj=$row["time"];
$nrnr=$row["content"];


?>
<form action="news_modi_save.php" method="post" name="formadd" onSubmit="return CheckForm();">
<h1 align="center">请修改信息</h1>
<table width="600" border="1" cellspacing="0" cellpadding="2" align="center">
  <tr>
    <td width="86" bgcolor="#99FF66">标题</td>
    <td width="500"><input name="bt" type="text" size="60" maxlength="60" value="<?php echo $btbt;?>"></td>
  </tr>
  <tr>
    <td bgcolor="#99FF66">类别</td>
    <td><select name="lb" size="1">
<?php
$sql = "Select bigclassname From bigclass";
$myqueryf=mysqli_query($db,$sql);
while($row = mysqli_fetch_array($myqueryf))
{

?> 
      <option <?php if($row["bigclassname"]==$lblb) echo "selected"; ?> value="<?php echo $row["bigclassname"] ?>"><?php echo $row["bigclassname"]; ?></option>
<?php
}
?>     
	</select>
	</td>
  </tr>
  <tr>
    <td bgcolor="#99FF66">时间</td>
    <td>
	<input name="sj" type="text" value="<?php echo $sjsj;?>" size="60" maxlength="60" readonly="true" id="select_date" onFocus="javascript:ShowCalendar(this.id)">
	</td>
  </tr>
  <tr>
    <td bgcolor="#99FF66">内容</td>
    <td><textarea name="nr" cols="60" rows="7"><?php echo $nrnr;?></textarea></td>
  </tr>
  <tr>
    <td colspan="2" align="center">
	<input name="xwh" type="hidden" value="<?php echo $xwh;?>">
	<input name="pg" type="hidden" value="<?php echo $pg;?>">
	
	<input name="tj" type="submit" value="提交">&nbsp;
	<input name="qx" type="button" value="取消" onClick="history.back();">
	</td>
  </tr>
</table>
</form>

</body>
</html>
<script language="javascript">
function CheckForm()
{
if(document.formadd.bt.value.trim()=="")
{
        alert("输入标题");
		document.formadd.bt.focus();
		return false;
}

if(document.formadd.nr.value.trim()=="")
{
        alert("输入内容");
		document.formadd.nr.focus();
		return false;
}

return true;
}


