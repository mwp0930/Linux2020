<?php 
include("Conn.php");
$xwh = $_POST["xwh"];//������
$pg = $_POST["page"];
$bbtt = $_POST["bt"];
$lblb = $_POST["lb"];
$sjsj = $_POST["sj"];
$nrnr = $_POST["nr"];
$sql="update dlnews set title='$bbtt',bigclassname='$lblb',time='$sjsj',content='$nrnr' where ID =$xwh";
$result=mysqli_query($db,$sql);
if($result)
    echo "<script>{alert('修改成功');location.href='information_page.php?page=$pg'} </script>";
else 
    echo "<script>{alert('修改失败');history.back();} </script>";


?>

